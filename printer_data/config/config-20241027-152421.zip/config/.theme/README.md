# Mainsail theme blurry

![Screenshot 2023-11-27 051516](https://github.com/bumbeng/mainsail_theme_blurry/assets/111509593/88f39442-11f2-4772-9609-e520bf9de82e)


- make hidden folders visible
- create a folder called ./theme in machine section
- copy the downloaded files into this folder
- reload browser

